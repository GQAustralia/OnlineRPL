$('#search').relevantDropdown();

$('#name').relevantDropdown({
  fadeOutSpeed: 0
});