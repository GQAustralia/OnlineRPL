# Set this to the root of your project when deployed:
sass_dir = "/"
css_dir = "/"

# You can select your preferred output style here (can be overridden via the command line):
output_style = :compressed

sourcemap = true